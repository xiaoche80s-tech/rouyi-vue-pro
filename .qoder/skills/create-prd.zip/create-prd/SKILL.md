---
name: create-prd
description: 引导用户澄清需求后生成 PRD 文档，用户确认 PRD 无误后再生成 Task 分解文件。触发场景：用户要求创建 PRD、产品需求文档、功能规划，或用户说"写个PRD"、"新建需求"、"规划功能"。
---

# 创建 PRD 与 Task 分解

本 Skill 分三个阶段引导用户完成从需求澄清到任务拆解的全流程。

## 阶段一：需求澄清

在生成 PRD 之前，**必须**通过提问充分理解需求。使用 AskUserQuestion 工具或对话方式收集以下信息：

### 必选信息

1. **模块归属**：属于哪个业务模块？（如 opshub/system/im 等）
2. **功能概述**：用 1-2 句话描述要实现什么
3. **变更背景**：为什么要做这个功能？解决什么问题？
4. **影响范围**：涉及后端、前端、数据库哪些改动？

### 按需追问

根据用户回答，进一步澄清：

- **数据模型**：是否需要新建表？修改现有表？
- **API 设计**：需要哪些新接口？修改哪些现有接口？
- **前端交互**：页面布局、操作流程、权限控制
- **优先级**：哪些是 P0（必须），哪些是 P1/P2（可选）
- **边界条件**：并发、幂等、权限、异常处理
- **与现有模块的关系**：是否依赖或影响其他模块

### 澄清原则

- 每次最多问 3-4 个问题，避免信息过载
- 根据用户回答动态调整后续问题
- 如果用户已在初始描述中提供了足够信息，可跳过已知项
- 当信息充足时，明确告知用户"信息已充分，开始生成 PRD"

## 阶段二：生成 PRD

信息充分后，生成 PRD 文档并保存到 `docs/` 目录。

### 文件命名

`docs/PRD-StepXX-模块名称.md`（XX 为序号，参考已有 PRD 编号递增）

### PRD 模板

```markdown
# PRD-StepXX-模块名称

## 概述

一段话概括本 Step 的目标和核心价值。

## 变更背景

列出当前存在的问题或需求，说明为什么要做这个改动：
1. 问题一
2. 问题二
3. ...

## 变更内容

### 1. 功能点名称（P0/P1/P2）

**改动文件**：
- `文件路径` — 改动说明

**设计逻辑**：
- 核心业务规则和流程说明

**代码示例**（如需要）：
```java
// 关键逻辑伪代码
```

### 2. 功能点名称（P0/P1/P2）

...(按优先级排列)

## 页面元素规格

> 仅当功能点涉及前端界面时必填，按页面分组列出。每个页面分两部分：**Form 表单（输入项）** 和 **接口输出项（展示项）**。

### 页面名称（如：工单管理页）

#### Form 表单（输入项）

用户通过创建/编辑弹窗提交的字段：

| 字段名 | 元素类型 | 数据类型 | 取值范围 | 必填 | 读写 | 说明 |
|--------|----------|----------|----------|------|------|------|
| title | text | String | max=100 | 是 | 可写 | 工单标题 |
| categoryId | select | Long | 分类 API | 是 | 可写 | 工单分类 |
| assigneeId | select | Long | 用户列表 API | 否 | 可写 | 创建时可选，编辑时只读 |
| priority | radio | Integer | 0=普通 1=紧急 2=特急 | 是 | 可写 | 默认值=0 |
| remark | textarea | String | max=500 | 否 | 可写 | 多行文本输入 |
| attachments | upload | List | 图片/PDF, max=5 | 否 | 可写 | 附件上传 |

#### 接口输出项（展示项）

后端接口返回但不由用户输入的字段，用于列表列 / 详情展示：

| 字段名 | 数据类型 | 取值范围 | 说明 |
|--------|----------|----------|------|
| taskNo | String | 自动生成 | 工单编号，点击可查看详情 |
| status | Integer | 0=待接单 1=处理中 2=已交付 3=已关闭 | 状态标签，带颜色映射 |
| createTime | DateTime | 自动填充 | 创建时间 |
| creatorName | String | 接口关联 | 创建人姓名 |
| assigneeName | String | 接口关联 | 处理人姓名 |

### 页面名称（如：工单详情弹窗）

#### Form 表单（输入项）

> 如该页面无表单（纯展示），标注“无输入表单”即可。

| 字段名 | 元素类型 | 数据类型 | 取值范围 | 必填 | 读写 | 说明 |
|--------|----------|----------|----------|------|------|------|
| ... | ... | ... | ... | ... | ... | ... |

#### 接口输出项（展示项）

| 字段名 | 数据类型 | 取值范围 | 说明 |
|--------|----------|----------|------|
| ... | ... | ... | ... |

**元素类型枚举**：`text`（单行输入）| `select`（下拉选择）| `radio`（单选）| `checkbox`（多选）| `textarea`（多行文本）| `date`（日期选择）| `datetime`（日期时间）| `switch`（开关）| `upload`（文件上传）| `number`（数字输入）

**必填枚举**：`是` | `否` | `条件必填`（需说明条件，如“选择售后类型时必填”）

**读写枚举**：`可写` | `条件读写`（需说明条件，如“创建时可写，编辑时只读”）

## API 接口定义

> 列出本 Step 新增或修改的所有接口，每个接口包含请求/响应定义。

### 接口 1：创建工单

| 项 | 值 |
|------|------|
| 方法 | `POST` |
| 路径 | `/opshub/cs-task/create` |
| 权限 | `dealer:cs-task:create` |
| 说明 | 创建客服工单 |

**请求参数**（Body JSON）：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| title | String | 是 | 工单标题，max=100 |
| categoryId | Long | 是 | 工单分类 ID |
| assigneeId | Long | 否 | 执行人 ID |
| priority | Integer | 是 | 优先级：0=普通 1=紧急 2=特急 |
| remark | String | 否 | 备注，max=500 |

**响应**（`CommonResult<Long>`）：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| data | Long | 新建工单 ID |

### 接口 2：工单分页列表

| 项 | 值 |
|------|------|
| 方法 | `GET` |
| 路径 | `/opshub/cs-task/page` |
| 权限 | `dealer:cs-task:query` |
| 说明 | 分页查询工单列表 |

**请求参数**（Query）：

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| pageNo | Integer | 是 | 页码，默认 1 |
| pageSize | Integer | 是 | 每页条数，默认 10 |
| status | Integer | 否 | 状态筛选 |
| keyword | String | 否 | 工单编号/标题模糊搜索 |

**响应**（`CommonResult<PageResult<CsTaskRespVO>>`）：

| 参数名 | 类型 | 说明 |
|--------|------|------|
| data.list | List | 工单列表 |
| data.total | Long | 总条数 |

### 接口 N：...

（其他接口按相同格式列出）

### 项目接口规范

#### 统一响应格式 — `CommonResult<T>`

所有接口统一返回 `CommonResult<T>`，JSON 结构：

```json
{
  "code": 0,        // Integer, 0=成功，其他=错误码
  "msg": "",        // String, 错误提示（成功时为空）
  "data": {}         // T, 业务数据
}
```

| 状态 | code | msg | data |
|------|------|-----|------|
| 成功 | `0` | `""` | 业务数据 |
| 参数错误 | `400` | 具体提示 | `null` |
| 未登录 | `401` | `"账号未登录"` | `null` |
| 无权限 | `403` | `"没有该操作权限"` | `null` |
| 业务异常 | `1_xxx_xxx_xxx` | 具体提示 | `null` |
| 系统异常 | `500` | `"系统异常"` | `null` |

#### 分页响应格式 — `PageResult<T>`

分页查询返回 `CommonResult<PageResult<T>>`：

```json
{
  "code": 0,
  "msg": "",
  "data": {
    "list": [],      // List<T>, 数据列表
    "total": 100     // Long, 总条数
  }
}
```

#### 分页请求参数 — `PageParam`

分页查询 VO 继承 `PageParam`，默认包含：

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| pageNo | Integer | 1 | 页码，从 1 开始 |
| pageSize | Integer | 10 | 每页条数，最大 200；设为 -1 不分页 |

#### VO 命名规范

| VO 类型 | 命名格式 | 用途 | 示例 |
|---------|----------|------|------|
| 创建请求 | `XxxSaveReqVO` | 创建/保存接口入参 | `CsTaskCreateReqVO` |
| 更新请求 | `XxxUpdateReqVO` | 更新接口入参 | `SigningContractUpdateReqVO` |
| 分页查询 | `XxxPageReqVO` | 分页查询入参（继承 PageParam） | `CsTaskPageReqVO` |
| 操作请求 | `Xxx{Action}ReqVO` | 特定操作入参 | `CsTaskVerifyReqVO`、`CsTaskTransferReqVO` |
| 列表响应 | `XxxRespVO` | 列表/分页返回 | `CsTaskRespVO` |
| 详情响应 | `XxxDetailRespVO` | 详情接口返回 | `OrderDetailRespVO` |
| 简化响应 | `XxxSimpleRespVO` | 下拉选择等简化数据 | `DealerInfoSimpleRespVO` |
| 统计响应 | `XxxStatisticsRespVO` | 统计数据返回 | `OrderStatisticsRespVO` |

#### 接口路径规范

`/{module}/{resource}/{action}`，如 `/opshub/cs-task/create`

#### HTTP 方法约定

| 方法 | 场景 | 示例 |
|------|------|------|
| `POST` | 创建 / 执行操作 | `/create`、`/submit-for-approval`、`/accept` |
| `PUT` | 更新 | `/update` |
| `GET` | 查询 | `/page`、`/get`、`/list`、`/simple-list`、`/tab-counts` |
| `DELETE` | 删除 | `/delete` |

#### Controller 注解规范

```java
@RestController
@RequestMapping("/opshub/{resource}")
@Tag(name = "管理后台 - {resource中文名称}")
public class XxxController {

    @PostMapping("/create")
    @Operation(summary = "创建xxx")
    @PreAuthorize("@ss.hasPermission('dealer:xxx:create')")
    public CommonResult<Long> createXxx(@Valid @RequestBody XxxSaveReqVO reqVO) {
        return success(xxxService.createXxx(reqVO));
    }

    @GetMapping("/page")
    @Operation(summary = "获得xxx分页")
    @PreAuthorize("@ss.hasPermission('dealer:xxx:query')")
    public CommonResult<PageResult<XxxRespVO>> getXxxPage(@Valid XxxPageReqVO reqVO) {
        return success(xxxService.getXxxPage(reqVO));
    }
}
```

#### 权限码命名规范

`{角色域}:{资源}:{操作}`，如 `dealer:cs-task:create`

| 操作 | 权限码 | 对应接口 |
|------|---------|----------|
| 创建 | `xxx:create` | POST /create |
| 更新 | `xxx:update` | PUT /update |
| 删除 | `xxx:delete` | DELETE /delete |
| 查询 | `xxx:query` | GET /page、/get、/list |

## DDL 变更

列出数据库表结构变更（如有）：
- 新建文件路径
- SQL 语句

## DML 变更

列出数据初始化/权限菜单等变更（如有）：
- 新建文件路径
- SQL 语句

## 涉及文件清单

### 后端（yudao-module-xxx）
| 文件 | 操作 |
|------|------|
| `XxxServiceImpl.java` | 新增/修改/重构 |

### 前端（yudao-ui/yudao-ui-admin-vue3）
| 文件 | 操作 |
|------|------|
| `views/opshub/xxx/index.vue` | 新增/修改 |

### DDL/DML
| 文件 | 操作 |
|------|------|
| `db/branches/feature_stepXX/...` | 新建 |

## 已知限制

列出已知的技术限制或遗留问题。

## 剩余待做（P2/P3）

| 优先级 | 任务 | 说明 |
|-------|------|------|
| P2 | xxx | xxx |
```

### PRD 编写要求

- 每个功能点必须标注优先级（P0/P1/P2）
- 改动文件写清具体路径，不要用模糊描述
- 涉及权限变更要列出权限码和角色分配
- 代码示例用伪代码或关键逻辑片段，不写完整实现
- **涉及前端界面的功能点，必须在「页面元素规格」中分两部分列出**：Form 表单（输入项：字段名、元素类型、数据类型、取值范围、必填、读写）和接口输出项（展示项：字段名、数据类型、取值范围、说明）
- **涉及新增/修改后端接口的功能点，必须在「API 接口定义」中列出每个接口**：HTTP 方法、路径、权限码、请求参数（参数名/类型/必填/说明）、响应参数
- PRD 生成后，**告知用户审阅 PRD，确认无误后再生成 Task**

## 界面原型生成（可选）

当用户明确要求提供界面原型/线框图/UI 设计时，调用 `canvas` skill 生成可视化原型。

### 触发时机

以下任一场景均可触发：

- 用户在需求澄清阶段说"需要看下页面原型"、"画个界面"、"给我看下 UI"
- 用户在审阅 PRD 时说"这个页面画个原型看看"
- 用户主动要求"生成界面原型"、"画个线框图"

### 执行方式

调用 `canvas` skill（`/canvas`），传入以下上下文：

1. **页面名称**：对应 PRD 中的功能点
2. **布局描述**：从 PRD 的前端交互描述中提取
3. **组件类型**：基于项目技术栈（Vue3 + Element Plus），使用 Element Plus 组件构建
4. **交互说明**：按钮点击、表单校验、列表筛选等关键交互

### 与 PRD 的关联

- 原型生成后，在 PRD 对应功能点的「设计逻辑」部分追加原型引用：
  ```
  **界面原型**：见 Canvas 原型 `[canvas文件名]`
  ```
- 如果用户对原型提出调整，同步更新原型和 PRD 中的交互描述
- 原型确认后，Task 分解中前端相关 Task 应引用原型作为实现参考

### 原型调整联动

| 场景 | 原型更新 | PRD 更新 | Task 更新 |
|------|---------|---------|----------|
| 用户调整 UI 布局 | 重新调用 canvas | 更新前端交互描述 | 如已生成则同步 |
| 用户调整交互流程 | 重新调用 canvas | 更新设计逻辑 | 如已生成则同步 |
| 用户调整字段/表单 | 重新调用 canvas | 更新数据模型/VO | 如已生成则同步 |

## 阶段三：PRD 修订与同步

用户审阅 PRD 后可能提出调整意见，此时需要**就地修改已有 PRD 文件**（而非重新生成）。

### 修订触发条件

- 用户明确指出"需要修改"、"这里不对"、"加上 xxx"、"去掉 xxx"等
- 用户对某个功能点的设计逻辑、优先级、文件清单等提出异议

### 修订原则

1. **就地更新**：使用 SearchReplace 直接修改 `docs/PRD-StepXX-模块名称.md`，保留未变动的内容
2. **告知变更**：修改完成后简要说明"已更新 PRD：xxx"
3. **联动 Task**：如果 Task 文件（`.qoder/specs/stepXX-模块名称_task.md`）已生成，必须同步更新 Task 文件中受影响的部分（Task 列表、实施顺序、验证方式等）
4. **重新审阅**：修改后再次请用户确认，直到用户说"OK"、"没问题"、"确认"

### 修订与 Task 联动规则

| 场景 | PRD 更新 | Task 更新 |
|------|---------|----------|
| Task 尚未生成 | 更新 PRD，等待用户确认 | 无需操作 |
| Task 已生成，调整不影响 Task | 更新 PRD | 无需操作 |
| Task 已生成，调整影响 Task 内容 | 更新 PRD | 同步更新 Task 对应段落 |
| 用户新增/删除功能点 | 更新 PRD | 新增/删除对应 Task |
| 用户调整优先级 | 更新 PRD 中的 P0/P1/P2 | 更新实施顺序表 |

### 修订完成后

- 如果 Task 尚未生成：用户确认后进入**阶段四**生成 Task
- 如果 Task 已生成且已联动更新：告知用户 PRD 和 Task 均已更新，再次请确认

## 阶段四：生成 Task 分解

用户确认 PRD 后，生成 Task 文件保存到 `.qoder/specs/` 目录。

### 文件命名

`.qoder/specs/stepXX-模块名称_task.md`

### Task 模板

```markdown
# StepXX — 模块名称

## Context

简述当前状态和本 Step 目标，引用 PRD 文件。

---

## Task 1: 任务标题

**新建/修改文件**：`具体文件路径`

详细描述：
- 具体要实现的内容
- 字段、方法、接口定义
- 关键逻辑说明

---

## Task 2: 任务标题

**新建/修改文件**：`具体文件路径`

...

---

## Task N: 编译验证

- 后端：`mvn compile -pl yudao-module-xxx` 通过
- 前端：无 TypeScript 报错

---

## 实施顺序

| Task | 内容 | 依赖 |
|------|------|------|
| 1 | xxx | 无 |
| 2 | xxx | Task 1 |
| 3 | xxx | Task 1, 2 |

---

## 验证方式

| 验证项 | 操作 | 预期 |
|--------|------|------|
| xxx | 操作步骤 | 预期结果 |

---

## 风险与注意事项

| 风险 | 缓解措施 |
|------|---------|
| xxx | xxx |
```

### Task 编写要求

- 每个 Task 粒度适中，一般 1-3 个文件的改动为一个 Task
- Task 之间标注依赖关系
- 最后一个 Task 固定为编译验证
- 包含验证方式表格，便于验收
- 包含风险与注意事项

## 流程总结

```
用户发起需求 → 澄清提问（可多轮）→ 生成 PRD → 用户审阅 ──→ 确认 OK → 生成 Task → 用户审阅 ──→ 完成
                                                      ↓           ↓                ↓
                                                 提出调整    需要界面原型?      提出调整
                                                      ↓      → 调用 canvas         ↓
                                                 修订 PRD      → 关联 PRD     修订 PRD + 联动 Task
                                                      ↓           ↓                ↓
                                                 再次审阅     继续审阅         再次审阅
```
